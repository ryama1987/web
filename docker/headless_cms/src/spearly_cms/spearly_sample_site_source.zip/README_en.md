# Spearly CMS sample site source

## About this sample
This sample is based on Future Imperfect, a template by [HTML5 UP](https://html5up.net/).
It is free to use under the Creative Commons license.

## About checking the sample site
This sample source already contains the embed code for the Spearly CMS sample contents.
Drag and drop `index.html` into your browser to check the site. (Of course, you can also do this on your local server, etc.)

## Once you have verified your site
After you have verified that your site looks good, edit the sample content on the Spearly CMS or add new content, and see that it is immediately reflected on your site.

## Build your own site!
Once you have some understanding of how to use Spearly CMS, you can build your own site!
You may customize this sample source, or you may use it as a guide to create a completely new site.
Once you've created your site, use [Spearly CLOUD](https://cloud.spearly.com/) to distribute your site to the world!
