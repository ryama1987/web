<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=0">
    <meta property="og:type" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <meta property="og:description" content="">
    <meta property="og:site_name" content=""/>
    <meta property="og:title" content=""/>
    <link rel="stylesheet" href="/css/common.css">
    <link rel="stylesheet" href="/css/home.css">
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
    <!-- GoogleAnalytics -->
    <script src="/js/ga.js"></script>
    <!-- GoogleAnalytics -->
  </head>
  <body id="" class="">
    <div id="wrapper">
      <header>
       <div id="header" role="banner">
        </div><!-- header -->
      </header>
      <div id="gnavi" role="navigation">
        <ul>
          <li><a href="#" title=""></a></li>
          <li><a href="#" title=""></a></li>
          <li><a href="#" title=""></a></li>
          <li><a href="#" title=""></a></li>
          <li><a href="#" title=""></a></li>
        </ul>
      </div><!-- gnavi -->

      <div id="mainArea" role="main">
        <p class="modal_trigger">モーダル開く</p><!-- .modal_trigger -->
      </div><!-- mainArea -->
      <footer>
       <div id="footer" role="contentinfo">
        </div><!-- footer -->
      </footer>
      <!--予約モーダル-->
      <div class="modal">
        <div class="modal_wrap">
          <div class="modal_content">
            <div class="modal_area">
              <div class="modal_close"><span>閉じる</span><img src="/media/images/common/modal_close.png" width="45" height="45" alt=""></div>
              <div class="modal_cont">
              <p>ここにコンテンツ</p>
              </div>
            </div>
          </div><!-- .modal_content -->
        </div>
      </div>

    </div><!-- wrapper -->
    <script src="/js/jquery.js"></script>
    <script src="/js/easing.js"></script>
    <script src="/js/common.js"></script>
    <script>
      $(".modal_trigger").click(function(){
        $('body').addClass('modal_open');
        $('.modal').fadeIn();
        return false;
      });
      $(".modal,.modal_close").click(function(){
        $('.modal').fadeOut();
        $('body').removeClass('modal_open');
      });
      $(".modal_wrap").on("click", function(e) {
        event.stopPropagation();
      });
    </script>
  </body>
</html>
