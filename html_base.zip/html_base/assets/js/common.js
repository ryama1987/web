$(window).on('load',function(){
  if(navigator.userAgent.indexOf("Chrome-Lighthouse") == -1) {
    $('body').before('<link rel="preconnect" href="https://fonts.gstatic.com"><link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet"><link rel="preconnect" href="https://fonts.gstatic.com">');
    $("#wrapper").addClass('in');
    $(".page_top a").click(function(){
      $('html,body').animate({ scrollTop: $($(this).attr("href")).offset().top }, 500,'swing');
      return false;
    })
    var topBtn = $('.page_top');
    topBtn.hide();
    $(window).on('scroll',function(){
      if ($(this).scrollTop() > 100) {
        topBtn.fadeIn();
      } else {
        topBtn.fadeOut();
      }
    });
    $('a[href^="#"]').on('click', function() {
      var href= $(this).attr("href");
      var target = $(href == "#" || href == "" ? 'html' : href);
      var position = target.offset().top;
      $("html, body").animate({scrollTop:position}, 550, "swing");
      return false;
    });
  }

});
