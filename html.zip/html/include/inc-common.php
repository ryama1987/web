<head>
  <meta charset="utf-8">
  <meta http-equiv="x-dns-prefetch-control" content="on">
  <link rel='preconnect dns-prefetch' href="//marketingplatform.google.com/">
  <link rel='preconnect dns-prefetch' href="//www.google.com">
  <link rel='preconnect dns-prefetch' href="//www.googletagmanager.com">
  <link rel='preconnect dns-prefetch' href="//www.google-analytics.com">
  <link rel='preconnect dns-prefetch' href="//cdnjs.com">
  <link rel='preconnect dns-prefetch' href="//cdnjs.cloudflare.com">
  <link rel='preconnect dns-prefetch' href="//fontawesome.com">
  <link rel='preconnect dns-prefetch' href="//use.fontawesome.com">
  <link rel='preconnect dns-prefetch' href="//fonts.google.com">
  <title></title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">
  <meta property="og:description" content="">
  <meta property="og:site_name" content=""/>
  <meta property="og:title" content=""/>
  <link rel="stylesheet" href="/assets/css/common.css">
  <link rel="stylesheet" href="/assets/css/home.css">
  <link rel="stylesheet" href="/assets/css/lower.css">
  <link href="https://api.fontshare.com/v2/css?f[]=panchang@200,500,1,700,300,400,800,600&display=swap" rel="stylesheet">
  <script src="/assets/js/jquery.js"></script>
  <!-- GoogleAnalytics -->
  <!-- GoogleAnalytics -->
</head>
